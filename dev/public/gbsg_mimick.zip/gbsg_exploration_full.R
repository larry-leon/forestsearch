# Comprehensive exploration of GBSG dataset from survival package
library(survival)

# Load the cancer datasets (which includes gbsg)
data(cancer)

# Basic structure and summary
cat("=== GBSG Dataset Structure ===\n")
str(gbsg)

cat("\n=== Dataset Dimensions ===\n")
cat("Number of observations:", nrow(gbsg), "\n")
cat("Number of variables:", ncol(gbsg), "\n")

cat("\n=== Variable Summary ===\n")
summary(gbsg)

cat("\n=== Variable Types ===\n")
sapply(gbsg, class)

cat("\n=== Missing Values ===\n")
colSums(is.na(gbsg))

# Survival specific information
cat("\n=== Survival Information ===\n")
cat("Event rate:", mean(gbsg$status), "\n")
cat("Median follow-up time:", median(gbsg$rfstime), "\n")
cat("Range of follow-up times:", range(gbsg$rfstime), "\n")

# Correlation structure for continuous variables
cat("\n=== Correlation Matrix (Continuous Variables) ===\n")
continuous_vars <- c("age", "size", "nodes", "pgr", "er", "rfstime")
cor_matrix <- cor(gbsg[, continuous_vars], use = "complete.obs")
print(round(cor_matrix, 3))

# Distribution of categorical variables
cat("\n=== Categorical Variable Distributions ===\n")
cat("Menopausal status (meno: 0=pre, 1=post):\n")
print(table(gbsg$meno))
cat("Proportions:\n")
print(prop.table(table(gbsg$meno)))

cat("\nTumor grade (1=good, 2=moderate, 3=poor):\n")
print(table(gbsg$grade))
cat("Proportions:\n")
print(prop.table(table(gbsg$grade)))

cat("\nHormone therapy (0=no, 1=yes):\n")
print(table(gbsg$hormon))
cat("Proportions:\n")
print(prop.table(table(gbsg$hormon)))

cat("\nEvent status (0=censored, 1=event):\n")
print(table(gbsg$status))
cat("Proportions:\n")
print(prop.table(table(gbsg$status)))

# More detailed statistics for continuous variables
cat("\n=== Detailed Statistics for Continuous Variables ===\n")
continuous_stats <- data.frame(
  Variable = continuous_vars,
  Mean = round(sapply(gbsg[, continuous_vars], mean), 2),
  SD = round(sapply(gbsg[, continuous_vars], sd), 2),
  Min = sapply(gbsg[, continuous_vars], min),
  Q1 = sapply(gbsg[, continuous_vars], quantile, 0.25),
  Median = sapply(gbsg[, continuous_vars], median),
  Q3 = sapply(gbsg[, continuous_vars], quantile, 0.75),
  Max = sapply(gbsg[, continuous_vars], max)
)
print(continuous_stats)

# Save key statistics for later use
gbsg_stats <- list(
  n_obs = nrow(gbsg),
  n_vars = ncol(gbsg),
  event_rate = mean(gbsg$status),
  var_types = sapply(gbsg, class),
  var_names = names(gbsg),
  continuous_vars = continuous_vars,
  categorical_vars = c("meno", "grade", "hormon", "status"),
  cor_matrix = cor_matrix,
  continuous_stats = continuous_stats,
  meno_props = prop.table(table(gbsg$meno)),
  grade_props = prop.table(table(gbsg$grade)),
  hormon_props = prop.table(table(gbsg$hormon))
)

saveRDS(gbsg_stats, "gbsg_statistics.rds")
cat("\n=== Statistics saved to gbsg_statistics.rds ===\n")
