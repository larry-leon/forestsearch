# Advanced Synthetic Data Generation using synthpop (if available)
# This demonstrates the state-of-the-art method for synthetic data generation

library(survival)
data(cancer)

cat("================================================================================\n")
cat("ADVANCED SYNTHETIC DATA GENERATION USING SYNTHPOP\n")
cat("================================================================================\n\n")

# Try to install and use synthpop
cat("Attempting to install synthpop package...\n")
tryCatch({
  install.packages("synthpop", repos = "https://cloud.r-project.org", quiet = TRUE)
  library(synthpop)
  
  cat("SUCCESS: synthpop package installed and loaded!\n\n")
  
  # Generate synthetic data using synthpop
  cat("Generating synthetic GBSG dataset using synthpop...\n")
  cat("------------------------------------------------\n")
  
  # Prepare data (remove pid as it's just an identifier)
  gbsg_for_synth <- gbsg[, -1]  # Remove pid column
  
  # Generate synthetic data
  synth_result <- syn(gbsg_for_synth, 
                      seed = 123,
                      visit.sequence = c("age", "meno", "size", "grade", "nodes", 
                                       "pgr", "er", "hormon", "rfstime", "status"))
  
  # Extract synthetic data and add pid back
  synth_data <- synth_result$syn
  synth_data$pid <- 1:nrow(synth_data)
  synth_data <- synth_data[, names(gbsg)]  # Reorder columns
  
  # Compare with original
  cat("\n=== Comparison of synthpop results with original ===\n")
  cat("----------------------------------------------------\n")
  
  # Summary statistics comparison
  cat("\nVariable means comparison:\n")
  orig_means <- sapply(gbsg[, sapply(gbsg, is.numeric)], mean)
  synth_means <- sapply(synth_data[, sapply(synth_data, is.numeric)], mean)
  
  comparison <- data.frame(
    Variable = names(orig_means),
    Original = round(orig_means, 2),
    Synthetic = round(synth_means, 2),
    Diff_Pct = round(100 * abs(synth_means - orig_means) / orig_means, 1)
  )
  print(comparison, row.names = FALSE)
  
  # Utility evaluation
  cat("\n=== Utility Evaluation ===\n")
  cat("--------------------------\n")
  utility_result <- utility.gen(synth_result, gbsg_for_synth)
  cat("pMSE (propensity Mean Squared Error):", round(utility_result$pMSE, 4), "\n")
  cat("(Lower pMSE indicates better utility preservation)\n\n")
  
  # Save the synthpop result
  write.csv(synth_data, "gbsg_synthetic_synthpop.csv", row.names = FALSE)
  cat("Synthetic dataset saved as: gbsg_synthetic_synthpop.csv\n\n")
  
  cat("ADVANTAGES OF SYNTHPOP:\n")
  cat("----------------------\n")
  cat("1. Preserves multivariate relationships\n")
  cat("2. Handles mixed data types automatically\n")
  cat("3. Provides utility metrics\n")
  cat("4. Uses CART (Classification and Regression Trees) by default\n")
  cat("5. Can specify custom synthesis methods per variable\n")
  cat("6. Includes disclosure control features\n")
  
}, error = function(e) {
  cat("FAILED to install synthpop. Error message:\n")
  cat(as.character(e), "\n\n")
  
  cat("Alternative: You can install synthpop manually using:\n")
  cat("install.packages('synthpop')\n\n")
  
  cat("For now, the three methods already implemented provide good alternatives:\n")
  cat("1. Parametric simulation\n")
  cat("2. Copula-based simulation\n")
  cat("3. Bootstrap with perturbation\n")
})

cat("\n================================================================================\n")
cat("FINAL RECOMMENDATIONS FOR GBSG MOCK DATA GENERATION\n")
cat("================================================================================\n\n")

cat("BEST PRACTICES:\n")
cat("---------------\n")
cat("1. For RESEARCH purposes: Use synthpop or copula-based methods\n")
cat("2. For TESTING purposes: Bootstrap with perturbation is fastest\n")
cat("3. For TEACHING purposes: Parametric simulation is most interpretable\n")
cat("4. For PRIVACY preservation: synthpop with disclosure control\n\n")

cat("ABOUT 'MODGO' PACKAGE:\n")
cat("----------------------\n")
cat("After investigation, 'modgo' does not appear to be a standard R package.\n")
cat("Possible alternatives that might have been intended:\n")
cat("- 'modeest': For mode estimation\n")
cat("- 'mod': For modular programming\n")
cat("- 'goftest': For goodness-of-fit tests\n")
cat("- 'simglm': For simulating generalized linear models\n\n")

cat("The methods provided here (parametric, copula, bootstrap, and synthpop)\n")
cat("represent the current best practices for synthetic data generation.\n")
